package com.henkel.erp.user.services;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.henkel.erp.user.dao.GetMenuDao;
import com.henkel.erp.user.model.GetMenu;

@Service

public class GetMenuServicesImpl implements GetMenuServices{
	
	@Autowired
	public GetMenuDao getMenuDao;

	@Override
	public GetMenu GetMenuID(String id) {
		return getMenuDao.GetMenuID(id);
	}
}
