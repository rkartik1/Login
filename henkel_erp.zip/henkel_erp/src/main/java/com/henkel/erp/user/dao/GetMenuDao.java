package com.henkel.erp.user.dao;


import com.henkel.erp.user.model.GetMenu;

public interface GetMenuDao {
	
	public GetMenu GetMenuID(String id);

}
