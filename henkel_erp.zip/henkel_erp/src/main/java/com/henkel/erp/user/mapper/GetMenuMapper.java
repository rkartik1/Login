package com.henkel.erp.user.mapper;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.henkel.erp.user.model.GetMenu;

public class GetMenuMapper implements RowMapper<GetMenu> {


	public GetMenu  mapRow(ResultSet resultSet, int rowNum) throws SQLException {

		GetMenu getMenu=new GetMenu();
		getMenu.setId(resultSet.getInt("id"));
		getMenu.setPageName(resultSet.getString("PageName"));
		getMenu.setDescription(resultSet.getString("description"));
		getMenu.setPageName2(resultSet.getString("PageName2"));
		getMenu.setParentPageId(resultSet.getString("ParentPageId"));
		getMenu.setParent(resultSet.getString("parent"));
		
		return getMenu;
	}

}
