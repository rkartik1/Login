package com.henkel.erp.user.dao;


import com.henkel.erp.user.model.CustomerShow;

public interface CustomerShowDao {
	
	public CustomerShow CustomerShowID(String Id);

}
