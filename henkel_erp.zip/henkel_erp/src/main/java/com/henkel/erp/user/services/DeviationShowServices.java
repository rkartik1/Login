package com.henkel.erp.user.services;

import com.henkel.erp.user.model.DeviationShow;

public interface DeviationShowServices
{
	public DeviationShow DeviationShowID(String Id);
}
