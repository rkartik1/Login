package com.henkel.erp.user.mapper;

import java.sql.ResultSet;



import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.henkel.erp.user.model. DeviationShow;

public class DeviationShowMapper<T> implements RowMapper<DeviationShow> {

	@Override
	public  DeviationShow mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		 DeviationShow M_deviation_SHOW=new  DeviationShow();
		M_deviation_SHOW.setid(resultSet.getInt("id"));
		M_deviation_SHOW.setDistId(resultSet.getInt("DistId"));
		M_deviation_SHOW.setCustId(resultSet.getInt("CustId"));
		M_deviation_SHOW.setProId(resultSet.getInt("ProId"));
		M_deviation_SHOW.setvalue(resultSet.getFloat("value"));
		M_deviation_SHOW.setFromDate(resultSet.getDate("FromDate"));
		M_deviation_SHOW.setToDate(resultSet.getDate("ToDate"));
		return M_deviation_SHOW;
	}

}
