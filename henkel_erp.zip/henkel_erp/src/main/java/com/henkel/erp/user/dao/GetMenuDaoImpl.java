package com.henkel.erp.user.dao;

import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.*;
import com.henkel.erp.user.mapper.GetMenuMapper;
import com.henkel.erp.user.model.GetMenu;
@Repository
public class GetMenuDaoImpl implements GetMenuDao{
	
	@Autowired
	public DataSource dataSource;
	
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.setNamedParameterJdbcTemplate(new NamedParameterJdbcTemplate(dataSource));
	}



	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
		return namedParameterJdbcTemplate;
	}



	public void setNamedParameterJdbcTemplate(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public GetMenu GetMenuID(String id) {
		SimpleJdbcCall validateEmailTemplate=new SimpleJdbcCall(this.getDataSource()).
		withProcedureName("m_get_menu").
		withoutProcedureColumnMetaDataAccess().
		returningResultSet("menu_list",new GetMenuMapper()).
		declareParameters(new SqlParameter("@pId",Types.VARCHAR));
		SqlParameterSource inputParam=new MapSqlParameterSource().
		addValue("@pId",id);
		return ((List<GetMenu>)validateEmailTemplate.execute(inputParam).get("menu_list")).get(0);
	}
}
