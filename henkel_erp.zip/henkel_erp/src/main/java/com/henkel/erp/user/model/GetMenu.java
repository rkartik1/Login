package com.henkel.erp.user.model;

import java.io.Serializable;
import java.util.List;

public class GetMenu implements Serializable {
	
	private Integer id;
	private String PageName;
	private String description;
	private String PageName2;
	private String ParentPageId;
	private String parent;
	private List<GetMenuList> getMenu;
	
	
	
	
	public List<GetMenuList> getGetMenu() {
		return getMenu;
	}
	public void setGetMenu(List<GetMenuList> getMenu) {
		this.getMenu = getMenu;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPageName() {
		return PageName;
	}
	public void setPageName(String pageName) {
		PageName = pageName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPageName2() {
		return PageName2;
	}
	public void setPageName2(String pageName2) {
		PageName2 = pageName2;
	}
	public String getParentPageId() {
		return ParentPageId;
	}
	public void setParentPageId(String parentPageId) {
		ParentPageId = parentPageId;
	}
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	
	
}
