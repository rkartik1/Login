package com.henkel.erp.startup;

import java.util.ArrayList;
import java.util.HashMap;

//import javax.jws.soap.SOAPBinding;

import org.springframework.boot.logging.Slf4JLoggingSystem;

public class Snippet {
	public static void main(String[] args) {
		
		String s[]={"1","2","3","4"};
		ArrayList<String> map=new ArrayList<>();
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s.length;i++){
		   map.add("<td></td>");
		   if(map.size()==2){
			   
		   }
		}
		System.out.println(sb.toString());
	}
}

