package com.henkel.erp.user.model;

import java.io.Serializable;
import java.util.Date;

public class DeviationShow implements Serializable
{
	private Integer id;
	private Integer DistId;
	private Integer CustId;
	private Integer ProId;
	private Float value;
	private Date FromDate;
	private Date ToDate;
	
	
	
	
	public Integer getid() {
		return id;
	}
	public void setid(Integer id) {
		this.id = id;
	}
	public Integer getDistId() {
		return DistId;
	}
	public void setDistId(Integer DistId) {
		this.DistId = DistId;
	}
	public Integer getCustId() {
		return CustId;
	}
	public void setCustId(Integer CustId) {
		this.CustId = CustId;
	}
	public Integer getProId() {
		return ProId;
	}
	public void setProId(Integer ProId) {
		this.ProId = ProId;
	}
	public Float getvalue() {
		return value;
	}
	public void setvalue(Float value) {
		this.value = value;
	}
	
	public Date getFromDate() {
		return FromDate;
	}
	public void setFromDate(Date FromDate) {
		this.FromDate = FromDate;
	}
	
	public Date getToDate() {
		return ToDate;
	}
	public void setToDate(Date ToDate) {
		this.ToDate = ToDate;
	}
}
