package com.henkel.erp.controller;


import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.henkel.erp.user.model.GetMenu;
import com.henkel.erp.user.services.GetMenuServices;
@RestController
@RequestMapping("/Auth")

public class GetMenusController{
	
	
	
	
@Autowired
public GetMenuServices getMenuServices;
	

	@GetMapping(value="/GetMenu")
	public ResponseEntity<GetMenu> GetMenu(@RequestParam String id){
		GetMenu getMenu=getMenuServices.GetMenuID(id);
		return new ResponseEntity<GetMenu>(getMenu,HttpStatus.OK);
	

}
}
