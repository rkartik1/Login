package com.henkel.erp.user.dao;


import com.henkel.erp.user.model.DeviationShow;

public interface DeviationShowDao {
	
	public DeviationShow DeviationShowID(String Id);

}
