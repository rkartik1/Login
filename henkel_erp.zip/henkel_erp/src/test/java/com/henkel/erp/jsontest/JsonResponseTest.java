package com.henkel.erp.jsontest;

public class JsonResponseTest {

}
