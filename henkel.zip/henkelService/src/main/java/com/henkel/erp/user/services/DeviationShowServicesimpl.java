package com.henkel.erp.user.services;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.henkel.erp.user.dao.DeviationShowDao;
import com.henkel.erp.user.model.DeviationShow;

@Service

public class DeviationShowServicesimpl implements DeviationShowServices{
	
	@Autowired
	public DeviationShowDao deviationShowDao;

	@Override
	public DeviationShow DeviationShowID(String Id) {
		return deviationShowDao.DeviationShowID(Id);
	}
}
