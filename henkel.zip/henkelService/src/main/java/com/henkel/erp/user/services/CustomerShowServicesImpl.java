package com.henkel.erp.user.services;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.henkel.erp.user.dao.CustomerShowDao;
import com.henkel.erp.user.model.CustomerShow;

@Service

public class CustomerShowServicesImpl implements CustomerShowServices{
	
	@Autowired
	public CustomerShowDao CustomerShowDao;

	@Override
	public CustomerShow CustomerShowID(String Id) {
		return CustomerShowDao.CustomerShowID(Id);
	}
}
