package com.henkel.erp.user.model;

import java.io.Serializable;

public class CustomerShow implements Serializable
{
	private Integer id;
	private Integer DistId;
	private String CustCode;
	private String CustName;
	private String Address1;
	private String Address2;
	private String Address3;
	private Integer PinCode;
	private String Taluka;
	private String District;
	private Integer Phone;
	private String City;
	private Integer StateId;
	private Integer CountryId;
	private Integer KeyContact;
	private String Email;
	private String Website;
	private Integer Zone;
	private String Area;
	private String Segment;
	private String SubSegment;
	private String SubSBU;
	private Integer CustomerGroup;
	private String IBSegment;
	private String ENac5;
	private String ENac6;
	private String MarketSeg;
	private String MarketSubSeg;
	private Integer HenkelSalesPerson;
	private String HenkelSalesPerson1;
	private String HenkelSalesPerson2;
	private String DistSalesPerson;
	private Integer IsApprove;
	private Integer ApproverID;
	
	
	
	public Integer getid() {
		return id;
	}
	public void setid(Integer id) {
		this.id = id;
	}
	public Integer getDistId() {
		return DistId;
	}
	public void setDistId(Integer DistId) {
		this.DistId = DistId;
	}
	public String getCustCode() {
		return CustCode;
	}
	public void setCustCode(String CustCode) {
		this.CustCode = CustCode;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String CustName) {
		this.CustName = CustName;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String Address1) {
		this.Address1 = Address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String Address2) {
		this.Address2 = Address2;
	}
	public String getAddress3() {
		return Address3;
	}
	public void setAddress3(String Address3) {
		this.Address3 = Address3;
	}
	public Integer getPinCode() {
		return PinCode;
	}
	public void setPinCode(Integer PinCode) {
		this.PinCode = PinCode;
	}
	public String getTaluka() {
		return Taluka;
	}
	public void setTaluka(String Taluka) {
		this.Taluka = Taluka;
	}
	public String getDistrict() {
		return District;
	}
	public void setDistrict(String District) {
		this.District = District;
	}
	public Integer getPhone() {
		return Phone;
	}
	public void setPhone(Integer Phone) {
		this.Phone = Phone;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String City) {
		this.City = City;
	}
	public Integer getStateId() {
		return StateId;
	}
	public void setStateId(Integer StateId) {
		this.StateId = StateId;
	}
	
	public Integer getCountryId() {
		return CountryId;
	}
	public void setCountryId(Integer CountryId) {
		this.CountryId = CountryId;
	}
	public Integer getKeyContact() {
		return KeyContact;
	}
	public void setKeyContact(Integer KeyContact) {
		this.KeyContact = KeyContact;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public String getWebsite() {
		return Website;
	}
	public void setWebsite(String Website) {
		this.Website = Website;
	}
	public Integer getZone() {
		return Zone;
	}
	public void setZone(Integer Zone) {
		this.Zone = Zone;
	}
	public String getArea() {
		return Area;
	}
	public void setArea(String Area) {
		this.Area = Area;
	}
	public String getSegment() {
		return Segment;
	}
	public void setSegment(String Segment) {
		this.Segment = Segment;
	}
	public String getSubSegment() {
		return SubSegment;
	}
	public void setSubSegment(String SubSegment) {
		this.SubSegment = SubSegment;
	}
	public String getSubSBU() {
		return SubSBU;
	}
	public void setSubSBU(String SubSBU) {
		this.SubSBU = SubSBU;
	}
	public Integer getCustomerGroup() {
		return CustomerGroup;
	}
	public void setCustomerGroup(Integer CustomerGroup) {
		this.CustomerGroup = CustomerGroup;
	}
	public String getIBSegment() {
		return IBSegment;
	}
	public void setIBSegment(String IBSegment) {
		this.IBSegment = IBSegment;
	}
	public String getENac5() {
		return ENac5;
	}
	public void setENac5(String ENac5) {
		this.ENac5 = ENac5;
	}
	public String getENac6() {
		return ENac6;
	}
	public void setENac6(String ENac6) {
		this.ENac6 = ENac6;
	}
	public String getMarketSeg() {
		return MarketSeg;
	}
	public void setMarketSeg(String MarketSeg) {
		this.MarketSeg = MarketSeg;
	}
	public String getMarketSubSeg() {
		return MarketSubSeg;
	}
	public void setMarketSubSeg(String MarketSubSeg) {
		this.MarketSubSeg = MarketSubSeg;
	}
	public Integer getHenkelSalesPerson() {
		return HenkelSalesPerson;
	}
	public void setHenkelSalesPerson(Integer HenkelSalesPerson) {
		this.HenkelSalesPerson = HenkelSalesPerson;
	}
	public String getHenkelSalesPerson1() {
		return HenkelSalesPerson1;
	}
	public void setHenkelSalesPerson1(String HenkelSalesPerson1) {
		this.HenkelSalesPerson1 = HenkelSalesPerson1;
	}
	public String getHenkelSalesPerson2() {
		return HenkelSalesPerson2;
	}
	public void setHenkelSalesPerson2(String HenkelSalesPerson2) {
		this.HenkelSalesPerson2 = HenkelSalesPerson2;
	}
	public String getDistSalesPerson() {
		return DistSalesPerson;
	}
	public void setDistSalesPerson(String DistSalesPerson) {
		this.DistSalesPerson = DistSalesPerson;
	}
	public Integer getIsApprove() {
		return IsApprove;
	}
	public void setIsApprove(Integer IsApprove) {
		this.IsApprove = IsApprove;
	}
	public Integer getApproverID() {
		return ApproverID;
	}
	public void setApproverID(Integer ApproverID) {
		this.ApproverID = ApproverID;
	}
	
}
