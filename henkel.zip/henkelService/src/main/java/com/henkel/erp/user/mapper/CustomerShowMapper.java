package com.henkel.erp.user.mapper;

import java.sql.ResultSet;



import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.henkel.erp.user.model.CustomerShow;

public class CustomerShowMapper<T> implements RowMapper<CustomerShow> {

	@Override
	public CustomerShow mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		CustomerShow customerShow=new CustomerShow();
		customerShow.setid(resultSet.getInt("id"));
		customerShow.setDistId(resultSet.getInt("DistId"));
		customerShow.setCustCode(resultSet.getString("CustCode"));
		customerShow.setCustName(resultSet.getString("CustName"));
		//customerShow.setAddress1(resultSet.getString("Address1"));
		//customerShow.setAddress2(resultSet.getString("Address2"));
		//customerShow.setAddress3(resultSet.getString("Address3"));
		//customerShow.setPinCode(resultSet.getInt("PinCode"));
		//customerShow.setTaluka(resultSet.getString("Taluka"));
		//customerShow.setDistrict(resultSet.getString("District"));
		//customerShow.setPhone(resultSet.getInt("Phone"));
		customerShow.setCity(resultSet.getString("City"));
		customerShow.setStateId(resultSet.getInt("StateId"));
		customerShow.setCountryId(resultSet.getInt("CountryId"));
		//customerShow.setKeyContact(resultSet.getInt("KeyContact"));
		//customerShow.setEmail(resultSet.getString("Email"));
		//customerShow.setWebsite(resultSet.getString("Website"));
		customerShow.setZone(resultSet.getInt("Zone"));
		//customerShow.setArea(resultSet.getString("Area"));
		//customerShow.setSegment(resultSet.getString("Segment"));
		//customerShow.setSubSegment(resultSet.getString("SubSegment"));
		//customerShow.setSubSBU(resultSet.getString("SubSBU"));
		customerShow.setCustomerGroup(resultSet.getInt("CustomerGroup"));
		//customerShow.setIBSegment(resultSet.getString("IBSegment"));
		//customerShow.setENac5(resultSet.getString("ENac5"));
		//customerShow.setENac6(resultSet.getString("ENac6"));
		//customerShow.setMarketSeg(resultSet.getString("MarketSeg"));
		//customerShow.setMarketSubSeg(resultSet.getString("MarketSubSeg"));
		customerShow.setHenkelSalesPerson(resultSet.getInt("HenkelSalesPerson"));
		//customerShow.setHenkelSalesPerson1(resultSet.getString("HenkelSalesPerson1"));
		//customerShow.setHenkelSalesPerson2(resultSet.getString("HenkelSalesPerson2"));
		customerShow.setDistSalesPerson(resultSet.getString("DistSalesPerson"));
		customerShow.setIsApprove(resultSet.getInt("IsApprove"));
		customerShow.setApproverID(resultSet.getInt("ApproverID"));
		
		return customerShow;
	}

}
