package com.henkel.erp.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.henkel.erp.user.model.CustomerShow;
import com.henkel.erp.user.services.CustomerShowServices;
@RestController
@RequestMapping("/customer")

public class CustomerShowController{
	
@Autowired
public CustomerShowServices customerShowServices;
	
	
	@RequestMapping(value="/validateUserByEmail",method=RequestMethod.GET)
	public ResponseEntity<CustomerShow> validateUserByEmail(@RequestParam String Id){
		CustomerShow customerShow=customerShowServices.CustomerShowID(Id);
		return new ResponseEntity<CustomerShow>(customerShow,HttpStatus.OK);
}
}
