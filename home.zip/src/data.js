// Gradients taken from: https://webgradients.com/
export default [
  {
    name: 'Secondary Sales',
    description:'#f5f7fa → #c3cfe2',
    css:'url("http://localhost:3000/images/Sales.png")',
    height: 200
  },
  {
    name: 'Market Data',
    description: '#f5f7fa → #c3cfe2',
    css: 'url("http://localhost:3000/images/MarketData.png")',
    height:200
  },
  {
    name: 'Distributor Appointment',
    description: '#e0c3fc → #8ec5fc',
    css: 'url("http://localhost:3000/images/DMT.png")',
    height: 200
  },
  {
    name: 'Admin',
    description: '#f093fb → #f5576c',
    css: 'url("http://localhost:3000/images/admin.png")',
    height: 200
  },
  
]
