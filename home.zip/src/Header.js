import React from 'react'
import {  Icon, Input } from 'antd'

export default function({
  
  search,
  margin
}) {
  return (
    <div className="header">
      <Input
        style={{ marginLeft: 900, minWidth: 130, maxWidth: 300 }}
        suffix={<Icon type="search" style={{ color: 'rgba(0,0,0,.25)' }} />}
        placeholder="input search text"
        onChange={search}
      />
    </div>
  )
}
